<footer class="blog-footer">
    <p><?php echo PROJECT_NAME; ?></p>
    <p>
        <a href="#">Back to top</a>
    </p>
</footer>