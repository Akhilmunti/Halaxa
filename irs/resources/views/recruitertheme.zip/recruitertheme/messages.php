<?php /*$message = $this->session->flashdata('notification'); ?>
<?php if ($message) { ?>
    <div class="alert alert-dark" role="alert">
        <?php echo $message; ?>
    </div>
<?php } */?>
