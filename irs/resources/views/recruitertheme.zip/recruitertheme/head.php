<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title><?php echo Config::get('constants.base.app_name'); ?></title>
    <meta content="<?php echo Config::get('constants.base.app_name'); ?>" name="description" />
    <meta content="<?php echo Config::get('constants.base.app_name'); ?>" name="author" />
    <link rel="shortcut icon" href="<?php echo url('/'); ?>/assets/images/favicon.png">

    <link href="<?php echo url('/'); ?>/assets/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="<?php echo url('/'); ?>/assets/halaxa-recruit.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?php echo url('/'); ?>/assets/recruit/form-wizard.css" rel="stylesheet" type="text/css">
</head>