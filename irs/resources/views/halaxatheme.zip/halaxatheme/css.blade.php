    <link rel="shortcut icon" href="<?php echo url('/'); ?>/assets/images/favicon.png">
    <link href="<?php echo url('/'); ?>/assets/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="<?php echo url('/'); ?>/assets/halaxa.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
