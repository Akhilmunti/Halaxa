 <div class="sidebar-header">
                        <a href="<?php echo url('/'); ?>/" class="no-decoration">
                            <img class="img-fluid logo-big" src="<?php echo url('/'); ?>/assets/images/logo.png" />
                        </a>
                        <a href="<?php echo url('/'); ?>" class="no-decoration">
                            <img class="img-fluid logo-small" src="<?php echo url('/'); ?>/assets/images/favicon.png" />
                        </a>
                    </div>

                    <ul class="list-unstyled components">
                        <!--                        <li class="active">
                                                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                                                        <i class="fas fa-home"></i>
                                                        Home
                                                    </a>
                                                    <ul class="collapse list-unstyled" id="homeSubmenu">
                                                        <li>
                                                            <a href="#">Home 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Home 2</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Home 3</a>
                                                        </li>
                                                    </ul>
                                                </li>-->
                        <li class="sidebar-li">
                            <a href="#">
                                <i class="span-icon">
                                    <img class="img-fluid" src="<?php echo url('/'); ?>/assets/images/find-jobs-icon.png" />
                                </i>
                                <span class="span-desc">
                                    Find Jobs
                                </span>
                            </a>
                        </li>
                        <li class="sidebar-li">
                            <a href="#">
                                <i class="span-icon">
                                    <img class="img-fluid" src="<?php echo url('/'); ?>/assets/images/applied-jobs-icon.png" />
                                </i>
                                <span>
                                    Applied Jobs
                                </span>
                            </a>
                        </li>
                        <li class="sidebar-li active">
                            <a href="#">
                                <i class="span-icon">
                                    <img class="img-fluid" src="<?php echo url('/'); ?>/assets/images/job-preferences-icon.png" />
                                </i>
                                <span>
                                    Job Preferences
                                </span>
                            </a>
                        </li>
                    </ul>
               