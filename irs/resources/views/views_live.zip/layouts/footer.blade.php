<footer>
      <div class="pull-right"> IRS | Foodlinked </div>
      <div class="clearfix"></div>
    </footer>
