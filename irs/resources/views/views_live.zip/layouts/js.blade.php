
<script src="<?php
echo url('/'); ?>/public/External/assets/js/jquery-2.2.4.min.js" type="text/javascript"></script>	
	<script src="<?php
echo url('/'); ?>/public/External/assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php
echo url('/'); ?>/public/External/assets/js/jquery.bootstrap.wizard.js" type="text/javascript"></script>
   <script src="<?php
echo url('/'); ?>/public/External/assets/js/paper-bootstrap-wizard.js" type="text/javascript"></script>
<!-- FastClick -->
<script src="<?php echo url('/'); ?>/public/External/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo url('/'); ?>/public/External/dist/js/crm.min.js"></script>

<script src="<?php echo url('/'); ?>/public/External/js/croppie.js"></script>
<script src="<?php echo url('/'); ?>/public/External/dist/js/gsdk-bootstrap-wizard.js"></script>
<script src="<?php echo url('/'); ?>/public/External/dist/js/jquery.validate.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo url('/'); ?>/public/External/dist/js/demo.js"></script>
<!-- CK Editor -->
<script src="<?php echo url('/'); ?>/public/External/bower_components/ckeditor/ckeditor.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo url('/'); ?>/public/External/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Select2 -->
<script src="<?php echo url('/'); ?>/public/External/bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?php echo url('/'); ?>/public/External/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?php echo url('/'); ?>/public/External/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?php echo url('/'); ?>/public/External/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="<?php echo url('/'); ?>/public/External/bower_components/moment/min/moment.min.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo url('/'); ?>/public/External/bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?php echo url('/'); ?>/public/External/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo url('/'); ?>/public/External/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?php echo url('/'); ?>/public/External/plugins/iCheck/icheck.min.js"></script>
<script src="<?php echo url('/'); ?>/public/External/build/js/custom.min.js"></script>

<script  src="<?php echo url('/'); ?>/public/External/stepper/js/jquery.smartWizard.js"></script>    
<script  src="<?php echo url('/'); ?>/public/External/stepper/js/nprogress.js"></script>
<script  src="<?php echo url('/'); ?>/public/External/validator/validator.js"></script>
    
<script src="<?php echo url('/'); ?>/public/External/js/bootstrap-progressbar.min.js"></script>
<!-- bootstrap-wysiwyg -->
<script src="<?php echo url('/'); ?>/public/External/js/bootstrap-wysiwyg.min.js"></script>
<script src="<?php echo url('/'); ?>/public/External/js/jquery.hotkeys.js"></script>
<script src="<?php echo url('/'); ?>/public/External/js/prettify.js"></script>
<script src="<?php echo url('/'); ?>/public/External/js/jquery.tagsinput.js"></script>
 <!-- Switchery -->
 <script src="<?php echo url('/'); ?>/public/External/js/switchery.min.js"></script>

    <script src="<?php echo url('/'); ?>/public/External/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo url('/'); ?>/public/External/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo url('/'); ?>/public/External/datepicker/js/bootstrap-datepicker.min.js"></script>

<script src="<?php echo url('/'); ?>/public/External/pnotify/tost/toast.js"></script>
<script src="<?php echo url('/'); ?>/public/External/pnotify/tost/toaster.js"></script>
<!-- Start of LiveChat (www.livechatinc.com) code -->
<script type="text/javascript">
    window.__lc = window.__lc || {};
    window.__lc.license = 11781699;
    (function () {
        var lc = document.createElement('script');
        lc.type = 'text/javascript';
        lc.async = true;
        lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(lc, s);
    })();
</script>
<noscript>
<a href="https://www.livechatinc.com/chat-with/11781699/" rel="nofollow">Chat with us</a>,
powered by <a href="https://www.livechatinc.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a>
</noscript>
<!-- End of LiveChat code -->

