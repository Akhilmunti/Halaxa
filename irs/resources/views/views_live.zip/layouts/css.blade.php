  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/bower_components/bootstrap/dist/css/bootstrap.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/dist/css/crm.min.css">
   <!-- bootstrap-progressbar -->
   <link href="<?php echo url('/'); ?>/public/External/bower_components/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
  
    <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/css/croppie.css" />
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/dist/css/skins/skin-green.min.css">
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/css/switchery.min.css" rel="stylesheet">

    <!-- bootstrap-daterangepicker -->
    <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/bower_components/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/datepicker/css/bootstrap-datepicker3.css" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/build/css/custom.min.css">
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/stepper/css/nprogress.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/plugins/iCheck/all.css">
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/plugins/iCheck/flat/green.css">
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/dist/css/gsdk-bootstrap-wizard.css">


  
    <link href="<?php echo url('/'); ?>/public/External/pnotify/tost/css.css" rel="stylesheet">
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo url('/'); ?>/public/External/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  
  <link href="http://staging.foodlinked.co.in/social/assets/theme.css" rel="stylesheet">
