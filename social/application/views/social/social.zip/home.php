<?php //echo '<pre>';print_r($connected_users);exit;                                                                     ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php $this->load->view('social/partials/assets-head') ?>
        <!-- Custom Theme Style -->
        <link href="<?php echo base_url(); ?>assets/build/css/custom.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/prod/override-classes.css" rel="stylesheet" type="text/css">

        <style>
            .custom-file-upload {
                border:  #ccc;
                display: inline-block;
                cursor: pointer;
                font-size: 14px;
                margin-right: 10px
            }    

        </style>
    </head>
    <body class="nav-md">
        <div class="container body">
            <div class="main_container">
                <?php $this->load->view('social/partials/left-nav'); ?>    
                <?php $this->load->view('social/partials/top-nav'); ?>
                <!-- page content -->
                <div class="right_col" role="main">
                    <?php $this->load->view('buyer/partials/searchbar'); ?> 
                    <div class="">
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="x_panel">
                                    <div class="x_title">
                                        <h2><?php echo $Name; ?> 's Wall</h2>
                                        <!--  <ul class="nav navbar-right panel_toolbox">
                                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a> </li>
                                            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                              <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a> </li>
                                                <li><a href="#">Settings 2</a> </li>
                                              </ul>
                                            </li>
                                            <li><a class="close-link"><i class="fa fa-close"></i></a> </li>
                                          </ul>-->
                                        <div class="clearfix"></div>
                                    </div>
                                    <?php
                                    $commentNot = $this->session->flashdata('commentMessage');
                                    if ($commentNot == NULL) {
                                        $hidealert = "hide";
                                    } else {
                                        $showalert = $commentNot;
                                        $hidealert = "";
                                    }
                                    ?>
                                    <div class="alert alert-success <?php echo $hidealert ?>">
                                        <?php echo $showalert ?>
                                    </div>
                                    <form method="post" enctype="multipart/form-data" action="<?php echo base_url() ?>social/add_posts">  
                                        <input type="hidden" name="Hidden_User_Id" value="<?php echo $Hidden_User_Id; ?>" />
                                        <div class="x_content">
                                            <div class="row">

                                                <?php if ($Hidden_User_Id) { ?>
                                                    <div class="col-md-12 col-sm-12 col-xs-12 form-group form-group-back p-10">
                                                        <input type="text" id="content" name="content" placeholder="Post Something" class="form-control">
                                                        <div class="pull-left p-10 links-post"> 
                                                            <a class="custom-file-upload" href="#" data-toggle="modal" data-target="#myModalImage"><i class="fa fa-picture-o"></i> <b>Add Image</b> </a> 

                                                            <!-- Modal -->
                                                            <div id="myModalImage" class="modal fade" role="dialog">
                                                                <div class="modal-dialog">
                                                                    <!-- Modal content-->
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                            <h4 class="modal-title">Image Upload</h4>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <input class="form-control" type="file" name="image" accept=".png, .jpg, .jpeg, .gif" onchange="loadFile(event)"/>
                                                                            <br>
                                                                            <img id="output" width="100%" height="300"/>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Save</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <a class="custom-file-upload" href="#" data-toggle="modal" data-target="#myModalVideo"><i class="fa fa-video-camera"></i> <b>Add Video</b> </a> 

                                                            <!-- Modal -->
                                                            <div id="myModalVideo" class="modal fade" role="dialog">
                                                                <div class="modal-dialog">
                                                                    <!-- Modal content-->
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                            <h4 class="modal-title">Video Upload</h4>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <input type="file" class="file_multi_video form-control" name="video" accept="video/mp4, video/MPG, video/* " /> 
                                                                            <br>
                                                                            <video width="100%" height="300" controls>
                                                                                <source src="mov_bbb.mp4" id="video_here">
                                                                                Your browser does not support HTML5 video.
                                                                            </video>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Save</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <a class="custom-file-upload" href="#" data-toggle="modal" data-target="#myModalLink"><i class="fa fa-video-camera"></i> <b>Add Link</b> </a> 

                                                            <!-- Modal -->
                                                            <div id="myModalLink" class="modal fade" role="dialog">
                                                                <div class="modal-dialog">
                                                                    <!-- Modal content-->
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                            <h4 class="modal-title">Link Upload</h4>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <input class="form-control" type="file" name="link" accept=".xlsx,.pdf,.doc,.docx,.ppt,.pptx,.pps,.ppsx,.xls,.xlsx" />
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Save</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div><br><br><br>
                                                        <div class="pull-right p-10">
                                                            <!--<a href="#"  class="btn btn-xs btn-info"> Network <i class="fa fa-globe"></i></a> -->
                                                            <input type="submit" class="btn btn-dark" onclick="return empty_validate()" value="Post"/> 
                                                        </div><br><br>
                                                    </div>

                                                <?php } ?>
                                                <div class="clearfix"></div>
                                                <div class="col-md-12"> 
                                                    <!-- end of user messages -->
                                                    <ul class="messages">
                                                        <?php
                                                        if ($posts) {
                                                            foreach ($posts as $val) {
                                                                ?>  
                                                                <li>
                                                                    <a href="<?php echo base_url(); ?>profile/index/<?php echo $val->Posted_User_Id; ?>"> 
                                                                        <?php
                                                                        if (!empty($val->Photo)) {
                                                                            ?>
                                                                            <!-- Current avatar -->
                                                                            <img src="<?php echo base_url(); ?>assets/photo/<?php echo $val->Photo; ?>" class="avatar" alt="Avatar">
                                                                        <?php } else { ?>
                                                                            <img src="<?php echo base_url(); ?>/assets/images/favi.jpg" alt="..." class="avatar">
                                                                        <?php } ?>
                                                                    </a>
                                                                    <div class="message_date">
                                                                        <?php $exp = explode(" ", $val->Date_Created); ?>
                                                                        <b class="month">
                                                                            <?php echo date("d", strtotime($exp[0])) . " " . date("F", strtotime($exp[0])); ?>
                                                                        </b><br>
                                                                        <b class="month"><?php echo substr($exp[1], 0, 5); ?></b><br>
                                                                    </div>

                                                                    <div class="message_wrapper">
                                                                        <a href="<?php echo base_url(); ?>profile/index/<?php echo $val->Posted_User_Id; ?>">
                                                                            <h4 class="heading"><?php echo $val->Name; ?></h4>
                                                                        </a>
                                                                        <p class="message"><?php echo $val->Content; ?></p>
                                                                        <br />

                                                                        <?php if ($val->Image) { ?>
                                                                            <img src="<?php echo base_url(); ?>assets/posts/<?php echo $val->Image; ?>" width="320" height="240" />

                                                                            <?php
                                                                        }

                                                                        if ($val->Video) {
                                                                            ?>
                                                                            <video width="320" height="240" controls>
                                                                                <source src="<?php echo base_url(); ?>assets/posts/<?php echo $val->Video; ?>" >
                                                                                Your browser does not support the video tag.
                                                                            </video>
                                                                            <?php
                                                                        }

                                                                        if ($val->Music) {
                                                                            ?>
                                                                            <audio controls>
                                                                                <source src="<?php echo base_url(); ?>assets/posts/<?php echo $val->Music; ?>" >
                                                                                Your browser does not support the audio tag.
                                                                            </audio>
                                                                            <?php
                                                                        }

                                                                        if ($val->Link) {
                                                                            ?>
                                                                            <a class="label label-success" href="<?php echo base_url(); ?>assets/posts/<?php echo $val->Link; ?>" target="_blank"><?php echo $val->Link; ?></a> 
                                                                            <br>
                                                                        <?php }
                                                                        ?>
                                                                        <br>
                                                                        <?php
                                                                        $status = $this->social_model->check_like($val->P_ID, $val->User_Id);
                                                                        if ($status[0]['status'] == ""):
                                                                            ?>
                                                                            <a href="<?php echo base_url() ?>social/likePost/<?php echo $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-thumbs-up"></i> (<?php echo $val->count; ?>) Like</a>
                                                                        <?php elseif ($status[0]['status'] == "0"): ?>
                                                                            <a href="<?php echo base_url() ?>social/likePost/<?php echo $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-thumbs-up"></i> (<?php echo $val->count; ?>) Like</a>
                                                                        <?php else: ?>
                                                                            <a href="<?php echo base_url() ?>social/likePost/<?php echo $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-thumbs-down"></i> (<?php echo $val->count; ?>) Unlike</a>
                                                                        <?php endif; ?>
                                                                        <a href="#" data-toggle="modal" data-target="#comment<?php echo "_" . $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-comments"></i> Comment</a>
                                                                        <a href="#" data-toggle="modal" data-target="#share<?php echo "_" . $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-share-alt-square"></i> Share</a>
                                                                        <a href="<?php echo base_url() ?>social/deletePost/<?php echo $val->P_ID; ?>"> <i class="fa fa-trash-o"></i> Delete</a>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-12">
                                                                            <ul class="messages">
                                                                                <?php $comments = $this->social_model->get_comments($val->P_ID); ?>
                                                                                <?php if ($comments != "") { ?>
                                                                                    <?php
                                                                                    foreach ($comments as $com) {
                                                                                        ?>
                                                                                        <li> 
                                                                                            <?php $user = $this->users_model->get_user_by_id($com['User_commented_id']); ?>
                                                                                            <?php
                                                                                            if (!empty($user->Photo)) {
                                                                                                ?>
                                                                                                <!-- Current avatar -->
                                                                                                <img src="<?php echo base_url(); ?>assets/photo/<?php echo $user->Photo; ?>" class="avatar" alt="Avatar">
                                                                                            <?php } else { ?>
                                                                                                <img src="<?php echo base_url(); ?>/assets/images/favi.jpg" alt="..." class="avatar">
                                                                                            <?php } ?>
                                                                                            <div class="message_date">
                                                                                                <b class="month">
                                                                                                    <a href="<?php echo base_url() ?>social/deleteComment/<?php echo $com['C_Id']; ?>" class="fa fa-trash-o"></a>
                                                                                                </b>
                                                                                            </div>
                                                                                            <div class="message_wrapper">
                                                                                                <h5><?php echo $user->Username; ?></h5>
                                                                                                <p class="message"><?php echo $com['Content']; ?></p>
                                                                                            </div>   
                                                                                        </li>
                                                                                    <?php }
                                                                                    ?>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </ul>
                                                    <!-- end of user messages -->

                                                </div>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /page content --> 

                <?php
                $i = 1;
                foreach ($posts as $val) {
                    ?>
                    <!-- Modal -->
                    <div id="comment<?php echo "_" . $val->P_ID; ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <form method="post" enctype="multipart/form-data" action="<?php echo base_url() ?>social/add_comment/<?php echo $val->P_ID; ?>">  
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Add Comment</h4>
                                    </div> 
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12 form-group form-group-back p-10">
                                                <input required="" type="text" id="comment" name="comment" placeholder="Post Comment" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-dark">Post</button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }
                ?>

                <?php
                $i = 1;
                foreach ($posts as $val) {
                    ?>
                    <!-- Modal -->
                    <div id="share<?php echo "_" . $val->P_ID; ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Share Post</h4>
                                </div> 
                                <div class="modal-body">
                                    <div class="row text-center">
                                        <a target="_blank" href="http://www.facebook.com/sharer.php?u=<?php echo base_url(); ?>social/singlePost/<?php echo $val->P_ID; ?>" class="fa fa-facebook-official fa-5x"></a>
                                        <a target="_blank" href="http://twitter.com/share?url=<?php echo base_url(); ?>social/singlePost/<?php echo $val->P_ID; ?>" class="fa fa-twitter-square fa-5x"></a>
                                        <a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo base_url(); ?>social/singlePost/<?php echo $val->P_ID; ?>" class="fa fa-linkedin-square fa-5x"></a>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }
                ?>
                <!-- footer content -->
                <?php $this->load->view('social/partials/footer') ?>
                <!-- /footer content --> 
            </div>
        </div>

        <?php $this->load->view('social/partials/assets-footer'); ?>
        <!-- Custom Theme Scripts --> 
        <script src="<?php echo base_url(); ?>assets/build/js/custom.min.js"></script> 
<!--        <script>
                                                            document.addEventListener("touchstart", function () {}, true);

                                                            function empty_validate()
                                                            {

                                                                if (document.getElementById('content').value == '')
                                                                {
                                                                    alert('Please enter your ideas');
                                                                    return false;
                                                                } else
                                                                {
                                                                    return true;
                                                                }
                                                            }

        </script>-->
        <script>
                                                                                                                                        function addId(id) {
                                                                                                                                            var id = id
                                                                                                                                            alert(id);
                                                                                                                                            $.ajax({
                                                                                                                                                type: "post",
                                                                                                                                                url: "<?php echo base_url('controller/function'); ?>",
                                                                                                                                                data: {id: id},
                                                                                                                                                cache: false,
                                                                                                                                                async: false,
                                                                                                                                                success: function (result) {
                                                                                                                                                    console.log(result);
                                                                                                                                                }
                                                                                                                                            });

                                                                                                                                        }
        </script>
        <script>
            // Type change event
            $('#filterby').change(function () {
                $.post("<?php echo base_url('buyer/search/getFilterResults/'); ?>",
                        {
                            filter: this.value,
                        },
                        function (data, status) {
                            $('#products').html(data);
                        });
            });


        </script>
        <script>
            var loadFile = function (event) {
                var output = document.getElementById('output');
                output.src = URL.createObjectURL(event.target.files[0]);
            };

            $(document).on("change", ".file_multi_video", function (evt) {
                var $source = $('#video_here');
                $source[0].src = URL.createObjectURL(this.files[0]);
                $source.parent()[0].load();
            });
        </script>
    </body>

</html>