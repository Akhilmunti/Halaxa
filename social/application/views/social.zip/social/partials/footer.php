<footer>
    <div class="pull-right"> <?php echo PROJECT_NAME; ?> | Social </div>
    <div class="clearfix"></div>
</footer>