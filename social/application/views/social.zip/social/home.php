<!DOCTYPE html>
<html lang="en">
    <!-- Header -->
    <?php $this->load->view('social/halaxa_partials/header'); ?>

    <body>
        <!-- Main -->
        <div class="main">
            <!-- Navbar -->
            <?php $this->load->view('social/halaxa_partials/navbar'); ?>

            <div class="wrapper">
                <!-- Sidebar -->
                <?php $this->load->view('social/halaxa_partials/sidebar'); ?>

                <div id="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="theme-card mb-3">
                                    <div class="row">
                                        <div class="col-md-8 border-right-post">
                                            <div class="post-card p-4">
                                                <img class="img-fluid start-post-img" src="<?php echo base_url('assets/halaxa_dashboard/images/write-icon.png'); ?>" />
                                                <span class="start-post-text">Start a post</span>
                                            </div>
                                        </div>
                                        <div class="col-md-2 border-right-post">
                                            <div class="post-card p-4 text-center">
                                                <a href="#">
                                                    <img class="img-fluid start-post-img-picture" src="<?php echo base_url('assets/halaxa_dashboard/images/picture-icon.png'); ?>" />
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="post-card p-4 text-center">
                                                <a href="#">
                                                    <img class="img-fluid start-post-img-video" src="<?php echo base_url('assets/halaxa_dashboard/images/video-icon.png'); ?>" />
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="post-card-bottom p-3">
                                                <span class="write-post-text">Write a post <span class="text-dark-theme">on Halaxa</span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="theme-card mb-3">
                                            <div class="posts p-3 mb-3">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                        <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/halaxa_dashboard/images/user-img.png'); ?>" />
                                                    </div>
                                                    <div class="col-md-8 no-padding">
                                                        <ul class="list-inline">
                                                            <li class="list-inline-item">
                                                                <a class="no-decoration" target="_blank" href="#">
                                                                    <p class="post-user-text">
                                                                        Ahmed Adel
                                                                    </p>
                                                                    <p class="post-user-post">Manager</p>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-3 text-right">
                                                        <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-time-icon.png'); ?>" />
                                                        <span class="post-time-text mr-3">16 Hours</span>
                                                        <a href="#">
                                                            <img class="img-fluid post-settings-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-settings-icon.png'); ?>" />
                                                        </a>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <span class="post-message-text">
                                                            resolution he dissimilar precaution to e moments. Merit end sight front Manor equal it on again ye folly by match In so melancholy as an old get our.  
                                                            resolution he dissimilar precaution to e moments. Merit end sight front  
                                                        </span>
                                                    </div>
                                                    <div class="col-md-12 mt-3">
                                                        <span class="post-attachment">
                                                            <img class="img-fluid" src="<?php echo base_url('assets/halaxa_dashboard/images/post-img.png'); ?>" />
                                                        </span>
                                                    </div>
                                                    <div class="col-md-12 mt-3">
                                                        <div class="post-anchors">
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-heart-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">500</span>
                                                            </a>
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-comment-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">3 comments</span>
                                                            </a>
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-share-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">share</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="theme-card mb-3">
                                            <div class="posts p-3">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                        <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/halaxa_dashboard/images/user-img.png'); ?>" />
                                                    </div>
                                                    <div class="col-md-8 no-padding">
                                                        <ul class="list-inline">
                                                            <li class="list-inline-item">
                                                                <a class="no-decoration" target="_blank" href="#">
                                                                    <p class="post-user-text">
                                                                        Fahed Essa
                                                                    </p>
                                                                    <p class="post-user-post">Designer</p>
                                                                </a>
                                                            </li>
                                                            <li class="list-inline-item">
                                                                <img class="img-fluid post-mark-img" src="<?php echo base_url('assets/halaxa_dashboard/images/halaxa-mark-icon.png'); ?>" />
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-3 text-right">
                                                        <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-time-icon.png'); ?>" />
                                                        <span class="post-time-text mr-3">16 Hours</span>
                                                        <a href="#">
                                                            <img class="img-fluid post-settings-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-settings-icon.png'); ?>" />
                                                        </a>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <span class="post-message-text">
                                                            resolution he dissimilar precaution to e moments. Merit end sight front Manor equal it on again ye folly by match In so melancholy as an old get our.  
                                                            resolution he dissimilar precaution to e moments. Merit end sight front  
                                                        </span>
                                                    </div>
                                                    <div class="col-md-12 mt-3">
                                                        <span class="post-attachment">
                                                            <img class="img-fluid" src="<?php echo base_url('assets/halaxa_dashboard/images/picture-one.png'); ?>" />
                                                        </span>
                                                    </div>
                                                    <div class="col-md-12 mt-3">
                                                        <div class="post-anchors">
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-heart-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">500</span>
                                                            </a>
                                                            <a class="mr-2 no-decoration" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-comment-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">3 comments</span>
                                                            </a>
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-share-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">share</span>
                                                            </a>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="comments">
                                                <div class="collapse show post-comments border-top-post" id="collapseExample">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="comment-box p-3">
                                                                <div class="row">
                                                                    <div class="col-md-9">
                                                                        <input type="text" class="form-control form-control-post-comment" />
                                                                    </div>
                                                                    <div class="col-md-3 text-left">
                                                                        <a href="#" class="no-decoration comment-button">Add Comment</a>
                                                                    </div>
                                                                </div>
                                                                <div class="user-comments">
                                                                    <div class="row">
                                                                        <div class="col-md-12">
                                                                            <div class="main-comment mt-3 border-bottom-post">
                                                                                <p class="main-comment-text">
                                                                                    resolution he dissimilar precaution to e moments. Merit end sight front Manor equal it on again ye folly by match In so melancholy as an old get our. 
                                                                                </p>
                                                                                <div class="row">
                                                                                    <div class="col-md-1">
                                                                                        <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/halaxa_dashboard/images/user-img.png'); ?>" />
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <ul class="list-inline">
                                                                                            <li class="list-inline-item">
                                                                                                <a class="no-decoration" target="_blank" href="#">
                                                                                                    <p class="post-user-text">
                                                                                                        Fahed Essa
                                                                                                    </p>
                                                                                                </a>
                                                                                            </li>
                                                                                            <li class="list-inline-item">
                                                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-time-icon.png'); ?>" />
                                                                                                <span class="post-time-text mr-3">16 Hours</span>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="col-md-5 text-right">
                                                                                        <a href="#" class="mr-2 no-decoration">
                                                                                            <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-heart-icon.png'); ?>" />
                                                                                            <span class="post-anchors-text mr-3">500</span>
                                                                                        </a>
                                                                                        <a class="mr-2 no-decoration" href="#">
                                                                                            <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-comment-icon.png'); ?>" />
                                                                                            <span class="post-anchors-text mr-3">3 comments</span>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sub-comment border-top-post pt-3">
                                                                                    <div class="row">
                                                                                        <div class="col-md-1">
                                                                                            <img class="img-fluid sub-comment-img mt-4" src="<?php echo base_url('assets/halaxa_dashboard/images/arrow-top-icon.png'); ?>" />
                                                                                        </div>
                                                                                        <div class="col-md-11">
                                                                                            <p class="main-comment-text">
                                                                                                resolution he dissimilar precaution to e moments.
                                                                                            </p>
                                                                                            <div class="row">
                                                                                                <div class="col-md-1">
                                                                                                    <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/halaxa_dashboard/images/user-img.png'); ?>" />
                                                                                                </div>
                                                                                                <div class="col-md-6">
                                                                                                    <ul class="list-inline">
                                                                                                        <li class="list-inline-item">
                                                                                                            <a class="no-decoration" target="_blank" href="#">
                                                                                                                <p class="post-user-text">
                                                                                                                    Fahed Essa
                                                                                                                </p>
                                                                                                            </a>
                                                                                                        </li>
                                                                                                        <li class="list-inline-item">
                                                                                                            <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-time-icon.png'); ?>" />
                                                                                                            <span class="post-time-text mr-3">16 Hours</span>
                                                                                                        </li>
                                                                                                    </ul>
                                                                                                </div>
                                                                                                <div class="col-md-5 text-right">
                                                                                                    <a href="#" class="mr-2 no-decoration">
                                                                                                        <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-heart-icon.png'); ?>" />
                                                                                                        <span class="post-anchors-text mr-3">500</span>
                                                                                                    </a>
                                                                                                    <a class="mr-2 no-decoration" href="#">
                                                                                                        <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-comment-icon.png'); ?>" />
                                                                                                        <span class="post-anchors-text mr-3">3 comments</span>
                                                                                                    </a>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="main-comment mt-3 border-bottom-post">
                                                                                <p class="main-comment-text">
                                                                                    resolution he dissimilar precaution to e moments. Merit end sight front Manor equal it on again ye folly by match In so melancholy as an old get our. 
                                                                                </p>
                                                                                <div class="row">
                                                                                    <div class="col-md-1">
                                                                                        <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/halaxa_dashboard/images/user-img.png'); ?>" />
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <ul class="list-inline">
                                                                                            <li class="list-inline-item">
                                                                                                <a class="no-decoration" target="_blank" href="#">
                                                                                                    <p class="post-user-text">
                                                                                                        Fahed Essa
                                                                                                    </p>
                                                                                                </a>
                                                                                            </li>
                                                                                            <li class="list-inline-item">
                                                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-time-icon.png'); ?>" />
                                                                                                <span class="post-time-text mr-3">16 Hours</span>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="col-md-5 text-right">
                                                                                        <a href="#" class="mr-2 no-decoration">
                                                                                            <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-heart-icon.png'); ?>" />
                                                                                            <span class="post-anchors-text mr-3">500</span>
                                                                                        </a>
                                                                                        <a class="mr-2 no-decoration" href="#">
                                                                                            <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-comment-icon.png'); ?>" />
                                                                                            <span class="post-anchors-text mr-3">3 comments</span>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sub-comment">
                                                                                    <div class="row">
                                                                                        <div class="col-md-12">

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <a href="#" class="no-decoration pt-3 load-more-comments">Load More Comments</a>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="theme-card mb-3">
                                            <div class="posts-header pt-2 pb-2 pl-3">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <a href="#" class="mr-2 no-decoration">
                                                            <img class="img-fluid post-time-img-sm" src="<?php echo base_url('assets/halaxa_dashboard/images/post-heart-icon.png'); ?>" />
                                                            <span class="post-status-text">liked by </span>
                                                            <span class="post-status-text-by">Mohammed Saed</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="posts p-3 mb-3 border-top-post">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                        <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/halaxa_dashboard/images/user-img.png'); ?>" />
                                                    </div>
                                                    <div class="col-md-8 no-padding">
                                                        <ul class="list-inline">
                                                            <li class="list-inline-item">
                                                                <a class="no-decoration" target="_blank" href="#">
                                                                    <p class="post-user-text">
                                                                        Ahmed Adel
                                                                    </p>
                                                                    <p class="post-user-post">Manager</p>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-3 text-right">
                                                        <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-time-icon.png'); ?>" />
                                                        <span class="post-time-text mr-3">16 Hours</span>
                                                        <a href="#">
                                                            <img class="img-fluid post-settings-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-settings-icon.png'); ?>" />
                                                        </a>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <span class="post-message-text">
                                                            resolution he dissimilar precaution to e moments. Merit end sight front Manor equal it on again ye folly by match In so melancholy as an old get our.  
                                                            resolution he dissimilar precaution to e moments. Merit end sight front  
                                                        </span>
                                                    </div>
                                                    <div class="col-md-12 mt-3">
                                                        <div class="post-anchors">
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-heart-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">500</span>
                                                            </a>
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-comment-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">3 comments</span>
                                                            </a>
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-share-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">share</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="theme-card mb-3">
                                            <div class="posts-header pt-2 pb-2 pl-3">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <a href="#" class="mr-2 no-decoration">
                                                            <img class="img-fluid post-time-img-sm" src="<?php echo base_url('assets/halaxa_dashboard/images/post-comment-icon.png'); ?>" />
                                                            <span class="post-status-text">commented by </span>
                                                            <span class="post-status-text-by">Mohammed Saed</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="posts p-3 mb-3 border-top-post">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                        <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/halaxa_dashboard/images/user-img.png'); ?>" />
                                                    </div>
                                                    <div class="col-md-8 no-padding">
                                                        <ul class="list-inline">
                                                            <li class="list-inline-item">
                                                                <a class="no-decoration" target="_blank" href="#">
                                                                    <p class="post-user-text">
                                                                        Ahmed Adel
                                                                    </p>
                                                                    <p class="post-user-post">Manager</p>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-3 text-right">
                                                        <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-time-icon.png'); ?>" />
                                                        <span class="post-time-text mr-3">16 Hours</span>
                                                        <a href="#">
                                                            <img class="img-fluid post-settings-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-settings-icon.png'); ?>" />
                                                        </a>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <span class="post-message-text">
                                                            resolution he dissimilar precaution to e moments. Merit end sight front Manor equal it on again ye folly by match In so melancholy as an old get our.  
                                                            resolution he dissimilar precaution to e moments. Merit end sight front  
                                                        </span>
                                                    </div>
                                                    <div class="col-md-12 mt-3">
                                                        <div class="post-anchors">
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-heart-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">500</span>
                                                            </a>
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-comment-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">3 comments</span>
                                                            </a>
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-share-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">share</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="theme-card mb-3">
                                            <div class="posts-header pt-2 pb-2 pl-3">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <a href="#" class="mr-2 no-decoration">
                                                            <img class="img-fluid post-time-img-sm" src="<?php echo base_url('assets/halaxa_dashboard/images/post-share-icon.png'); ?>" />
                                                            <span class="post-status-text">shared by </span>
                                                            <span class="post-status-text-by">Mohammed Saed</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="posts p-3 mb-3 border-top-post">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                        <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/halaxa_dashboard/images/user-img.png'); ?>" />
                                                    </div>
                                                    <div class="col-md-8 no-padding">
                                                        <ul class="list-inline">
                                                            <li class="list-inline-item">
                                                                <a class="no-decoration" target="_blank" href="#">
                                                                    <p class="post-user-text">
                                                                        Ahmed Adel
                                                                    </p>
                                                                    <p class="post-user-post">Manager</p>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-3 text-right">
                                                        <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-time-icon.png'); ?>" />
                                                        <span class="post-time-text mr-3">16 Hours</span>
                                                        <a href="#">
                                                            <img class="img-fluid post-settings-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-settings-icon.png'); ?>" />
                                                        </a>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <span class="post-message-text">
                                                            resolution he dissimilar precaution to e moments. Merit end sight front Manor equal it on again ye folly by match In so melancholy as an old get our.  
                                                            resolution he dissimilar precaution to e moments. Merit end sight front  
                                                        </span>
                                                    </div>
                                                    <div class="col-md-12 mt-3">
                                                        <div class="post-anchors">
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-heart-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">500</span>
                                                            </a>
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-comment-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">3 comments</span>
                                                            </a>
                                                            <a href="#" class="mr-2 no-decoration">
                                                                <img class="img-fluid post-time-img" src="<?php echo base_url('assets/halaxa_dashboard/images/post-share-icon.png'); ?>" />
                                                                <span class="post-anchors-text mr-3">share</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- End Main -->

        <!-- jQuery  -->
        <?php $this->load->view('social/halaxa_partials/scripts'); ?>
    </body>

</html>