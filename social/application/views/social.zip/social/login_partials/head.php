<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <![endif]-->
    <title>Foodlinked</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="#">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/'); ?>Foodlinked_Sample/vendor.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/'); ?>Foodlinked_Sample/dashcore.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?php echo base_url('assets/'); ?>Foodlinked_Sample/css" type="text/css" rel="stylesheet">
    <!-- <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800" rel="stylesheet"> -->
    <link href="<?php echo base_url('assets/'); ?>Foodlinked_Sample/css(1)" type="text/css" rel="stylesheet">
    <!-- themeforest:css -->
    <!-- endinject -->
</head>
<style>
    .hide{
        display: none;
    }
</style>