<script src="https://apis.google.com/js/client:platform.js?onload=renderButton" async defer></script>
<script src="https://apis.google.com/js/client:platform.js?onload=renderButtonReg" async defer></script>
<meta name="google-signin-client_id" content="949757778087-7bhs8ku1ir1q9631rfciupfrn2emdbbh.apps.googleusercontent.com">
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-76592740-13');
</script>
