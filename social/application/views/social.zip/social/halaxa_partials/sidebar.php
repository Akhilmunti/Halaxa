<!-- Sidebar  -->
<nav id="sidebar">
    <div class="sidebar-header">
        <a href="<?php echo base_url(); ?>" class="no-decoration">
            <img class="img-fluid logo-big" src="<?php echo base_url('assets/halaxa_dashboard/images/logo.png'); ?>" />
        </a>
        <a href="<?php echo base_url(); ?>" class="no-decoration">
            <img class="img-fluid logo-small" src="<?php echo base_url('assets/halaxa_dashboard/images/favicon.png'); ?>" />
        </a>
    </div>
    
    <?php 
    if($sidebar == "feeds"){
        $feeds = "active";
    } else {
        $feeds = "";
    }
    ?>

    <ul class="list-unstyled components">
        <!--                        <li class="active">
                                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                                        <i class="fas fa-home"></i>
                                        Home
                                    </a>
                                    <ul class="collapse list-unstyled" id="homeSubmenu">
                                        <li>
                                            <a href="#">Home 1</a>
                                        </li>
                                        <li>
                                            <a href="#">Home 2</a>
                                        </li>
                                        <li>
                                            <a href="#">Home 3</a>
                                        </li>
                                    </ul>
                                </li>-->
        <li class="sidebar-li <?php echo $feeds; ?>">
            <a href="<?php echo base_url('home/actionFindJobs'); ?>">
                <i class="span-icon">
                    <img class="img-fluid" src="<?php echo base_url('assets/halaxa_dashboard/images/feeds-icon.png'); ?>" />
                </i>
                <span class="span-desc">
                    Feeds
                </span>
            </a>
        </li>
        <li class="sidebar-li">
            <a href="<?php echo base_url('home/actionAppliedJobs'); ?>">
                <i class="span-icon">
                    <img class="img-fluid" src="<?php echo base_url('assets/halaxa_dashboard/images/followers-icon.png'); ?>" />
                </i>
                <span>
                    Followers
                </span>
            </a>
        </li>
        <li class="sidebar-li">
            <a href="<?php echo base_url(); ?>">
                <i class="span-icon">
                    <img class="img-fluid" src="<?php echo base_url('assets/halaxa_dashboard/images/communities-icon.png'); ?>" />
                </i>
                <span>
                    My Communities
                </span>
            </a>
        </li>
        <hr class="hr-theme">
        <li class="sidebar-li sidenav-label">Profile</li>
        <li class="sidebar-li">
            <a href="<?php echo base_url(); ?>">
                <i class="span-icon">
                    <img class="img-fluid" src="<?php echo base_url('assets/halaxa_dashboard/images/profile-icon.png'); ?>" />
                </i>
                <span>
                    Recruiter Profile
                </span>
            </a>
        </li>
    </ul>
</nav>