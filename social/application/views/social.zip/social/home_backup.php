<?php //echo '<pre>';print_r($connected_users);exit;                                                                                                                                                                                                                                                                                   ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        $mUserId = $this->session->userdata('User_Id');
        if ($mUserId) {
            
        } else {
            $this->session->set_userdata('Username', $user->Username);
            $this->session->set_userdata('User_Id', $user->User_Id);
            $this->session->set_userdata('Name', $user->Name);
        }
        ?>
        <?php $this->load->view('social/partials/assets-head') ?>
        <style>
            .reply{
                cursor: pointer;
            }
        </style>
    </head>
    <body class="nav-md">
        <div class="container body">
            <div class="main_container">
                <?php $this->load->view('social/partials/left-nav'); ?>    
                <?php $this->load->view('social/partials/top-nav'); ?>
                <!-- page content -->
                <div class="right_col" role="main">

                    <div class="row">
                        <div class="col-md-12">
                            <?php $this->load->view('buyer/partials/searchbar'); ?> 
                        </div>
                        <div class="col-md-9">
                            <div class="">
                                <div class="clearfix"></div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <?php
                                        $commentNot = $this->session->flashdata('commentMessage');
                                        if ($commentNot == NULL) {
                                            $hidealert = "hide";
                                        } else {
                                            $showalert = $commentNot;
                                            $hidealert = "";
                                        }
                                        ?>
                                        <div class="alert alert-success <?php echo $hidealert ?>">
                                            <?php echo $showalert ?>
                                        </div>
                                    </div>

                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="x_panel">
                                            <div class="x_title">
                                                <h2><?php echo $Name; ?> 's Wall</h2>
                                                <div class="clearfix"></div>
                                            </div>
                                            <form method="post" enctype="multipart/form-data" action="<?php echo base_url() ?>social/add_posts">  
                                                <input type="hidden" name="Hidden_User_Id" value="<?php echo $Hidden_User_Id; ?>" />
                                                <div class="x_content">
                                                    <?php if ($Hidden_User_Id) { ?>
                                                        <div class="row">
                                                            <div class="col-md-12 col-xs-12">
                                                                <textarea rows="3" type="text" onchange="myChangeText(this)" id="content" name="content" placeholder="Post Something on <?php echo PROJECT_NAME; ?>" class="form-control comment-form"></textarea>
                                                                <br>
                                                            </div>
                                                            <div class="col-md-3 col-xs-4 text-center border-right" style="padding-top: 5px;padding-bottom: 5px">
                                                                <a href="#" data-toggle="modal" data-target="#myModalImage"><i class="fa fa-picture-o"></i> <b>Add Image</b> </a> 
                                                                <!-- Modal -->
                                                                <div id="myModalImage" class="modal fade" role="dialog">
                                                                    <div class="modal-dialog">
                                                                        <!-- Modal content-->
                                                                        <div class="modal-content">
                                                                            <div class="modal-header">
                                                                                <button type="button" class="close" id="imageClose">&times;</button>
                                                                                <h4 class="modal-title">Image Upload</h4>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <textarea rows="3" type="text" id="content_image" name="content" placeholder="Post Something on <?php echo PROJECT_NAME; ?>" class="form-control comment-form"></textarea>
                                                                                <br>
                                                                                <input class="form-control" type="file" id="image" name="image" accept=".png, .jpg, .jpeg, .gif" onchange="loadFile(event)"/>
                                                                                <br>
                                                                                <img id="output" width="100%" height="300"/>
                                                                            </div>
                                                                            <div class="modal-footer">
                                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                                                <button type="button" class="btn btn-danger" id="cancelImage">Reset</button>
                                                                                <button type="submit" class="btn btn-default">Post</button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3 col-xs-4 text-center border-right" style="padding-top: 5px;padding-bottom: 5px">
                                                                <a href="#" data-toggle="modal" data-target="#myModalVideo"><i class="fa fa-video-camera"></i> <b>Add Video</b> </a> 
                                                                <!-- Modal -->
                                                                <div id="myModalVideo" class="modal fade" role="dialog">
                                                                    <div class="modal-dialog">
                                                                        <!-- Modal content-->
                                                                        <div class="modal-content">
                                                                            <div class="modal-header">
                                                                                <button type="button" class="close" id="videoClose">&times;</button>
                                                                                <h4 class="modal-title">Video Upload</h4>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <textarea rows="3" type="text" id="content_video" name="content" placeholder="Post Something on <?php echo PROJECT_NAME; ?>" class="form-control comment-form"></textarea>
                                                                                <br>
                                                                                <input type="file" class="file_multi_video form-control" id="video" name="video" accept="video/mp4, video/MPG, video/* " /> 
                                                                                <br>
                                                                                <video id="videoPreview" width="100%" height="300" controls>
                                                                                    <source src="mov_bbb.mp4" id="video_here">
                                                                                    Your browser does not support HTML5 video.
                                                                                </video>
                                                                            </div>
                                                                            <div class="modal-footer">
                                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                                                <button type="button" class="btn btn-danger" id="cancelVideo">Reset</button>
                                                                                <button type="submit" class="btn btn-default">Post</button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3 col-xs-4 text-center" style="padding-top: 5px;padding-bottom: 5px">
                                                                <a href="#" data-toggle="modal" data-target="#myModalLink"><i class="fa fa-paperclip"></i> <b>Add File</b> </a>
                                                                <!-- Modal -->
                                                                <div id="myModalLink" class="modal fade" role="dialog">
                                                                    <div class="modal-dialog">
                                                                        <!-- Modal content-->
                                                                        <div class="modal-content">
                                                                            <div class="modal-header">
                                                                                <button type="button" id="linkClose" class="close">&times;</button>
                                                                                <h4 class="modal-title">Link Upload</h4>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <textarea rows="3" type="text" id="content_link" name="content" placeholder="Post Something on <?php echo PROJECT_NAME; ?>" class="form-control comment-form"></textarea>
                                                                                <br>
                                                                                <input class="form-control" type="file" id="link" name="link" accept=".pdf" />
                                                                            </div>
                                                                            <div class="modal-footer">
                                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                                                <button type="button" class="btn btn-danger" id="cancelLink">Reset</button>
                                                                                <button type="submit" class="btn btn-default">Post</button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3 col-xs-12 text-center">
                                                                <input type="submit" class="btn btn-dark btn-block" onclick="return empty_validate()" value="Post"/> 
                                                            </div>
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                            </form>
                                        </div> 
                                    </div>

                                    <div class="col-md-12">
                                        <!-- end of user messages -->
                                        <ul class="messages_custom">
                                            <?php
                                            if ($posts) {
                                                foreach ($posts as $val) {
                                                    //print_r($val);
                                                    ?>
                                                    <div class="x_panel">
                                                        <div class="x_content">
                                                            <li>
                                                                <a href="<?php echo base_url(); ?>profile/index/<?php echo $val->Posted_User_Id; ?>"> 
                                                                    <?php
                                                                    if (!empty($val->Photo)) {
                                                                        ?>
                                                                        <!-- Current avatar -->
                                                                        <img src="<?php echo base_url(); ?>assets/photo/<?php echo $val->Photo; ?>" class="avatar img-circle" alt="Avatar">
                                                                    <?php } else { ?>
                                                                        <img src="<?php echo base_url(); ?>assets/images/user.png" alt="..." class="avatar img-circle">
                                                                    <?php } ?>
                                                                </a>
                                                                <div class="message_date">
                                                                    <b>
                                                                        <?php if ($val->Designation) { ?>
                                                                            <?php echo $val->Designation; ?>
                                                                        <?php } ?>
                                                                    </b>
                                                                    <br>
                                                                    <?php $exp = explode(" ", $val->Date_Created); ?>
                                                                    <b class="month">
                                                                        <?php echo date("d", strtotime($exp[0])) . " " . date("F", strtotime($exp[0])); ?>, <?php echo substr($exp[1], 0, 5); ?>
                                                                    </b><br>
                                                                    <b class="month"><?php echo $val->Locations; ?></b><br>
                                                                </div>

                                                                <div class="message_wrapper">
                                                                    <a href="<?php echo base_url(); ?>profile/index/<?php echo $val->Posted_User_Id; ?>">
                                                                        <h4 class="heading">
                                                                            <?php echo $val->Name; ?>
                                                                            <?php if (!empty($val->Partner_type)) { ?>
                                                                                <span class="badge"><?php echo $val->Partner_type; ?> Partner</span>
                                                                            <?php } ?>
                                                                        </h4>
                                                                    </a>
                                                                    <p class="message">
                                                                        <?php
                                                                        $text = $val->Content;

                                                                        $url = '@(http)?(s)?(://)?(([a-zA-Z])([-\w]+\.)+([^\s\.]+[^\s]*)+[^,.\s])@';
                                                                        $text = preg_replace($url, '<a href="http$2://$4" target="_blank" title="$0">$0</a>', $text);
                                                                        echo $text;
                                                                        ?>
                                                                    </p>
                                                                    <br />

                                                                    <?php if ($val->Image) { ?>
                                                                        <img src="<?php echo base_url(); ?>assets/posts/<?php echo $val->Image; ?>" width="320" height="240" />

                                                                        <?php
                                                                    }

                                                                    if ($val->Video) {
                                                                        ?>
                                                                        <video width="320" height="240" controls>
                                                                            <source src="<?php echo base_url(); ?>assets/posts/<?php echo $val->Video; ?>" >
                                                                            Your browser does not support the video tag.
                                                                        </video>
                                                                        <?php
                                                                    }

                                                                    if ($val->Music) {
                                                                        ?>
                                                                        <audio controls>
                                                                            <source src="<?php echo base_url(); ?>assets/posts/<?php echo $val->Music; ?>" >
                                                                            Your browser does not support the audio tag.
                                                                        </audio>
                                                                        <?php
                                                                    }

                                                                    if ($val->Link) {
                                                                        ?>
                                                                        <iframe src="<?php echo base_url(); ?>assets/posts/<?php echo $val->Link; ?>" width="100%" height="400"> </iframe>
            <!--                                                                        <a class="label label-success" href="" target="_blank"><?php echo $val->Link; ?></a> -->
                                                                        <br><br>
                                                                    <?php }
                                                                    ?>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-md-12 col-xs-12">
                                                                        <?php $comments = $this->social_model->get_comments($val->P_ID); ?>
                                                                        <a><?php echo $val->count; ?> Likes</a> 
                                                                        | 
                                                                        <a>
                                                                            <?php
                                                                            if (!empty($comments)) {
                                                                                echo count($comments);
                                                                            } else {
                                                                                echo "0";
                                                                            }
                                                                            ?> 
                                                                            Comments
                                                                        </a>
                                                                        <hr>
                                                                        <?php
                                                                        $mSessionUserId = $this->session->userdata('User_Id');
                                                                        $status = $this->social_model->check_like($val->P_ID, $mSessionUserId);
                                                                        if ($status[0]['status'] == ""):
                                                                            ?>
                                                                            <a href="<?php echo base_url() ?>social/likePost/<?php echo $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-thumbs-up"></i> Like</a>
                                                                        <?php elseif ($status[0]['status'] == "0"): ?>
                                                                            <a href="<?php echo base_url() ?>social/likePost/<?php echo $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-thumbs-up"></i> Like</a>
                                                                        <?php else: ?>
                                                                            <a href="<?php echo base_url() ?>social/likePost/<?php echo $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-thumbs-down"></i> Unlike</a>
                                                                        <?php endif; ?>
                                                                        <a href="#" data-toggle="modal" data-target="#comment<?php echo "_" . $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-comments"></i> Comment</a>
                                                                        <a href="#" data-toggle="modal" data-target="#share<?php echo "_" . $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-share-alt-square"></i> Share</a>
                                                                        <?php if ($mSessionUserId == $val->Posted_User_Id) { ?>
                                                                            <a style="padding-right: 25px;" href="<?php echo base_url() ?>social/deletePost/<?php echo $val->P_ID; ?>"> <i class="fa fa-trash-o"></i> Delete</a>
                                                                        <?php } ?>
                                                                        <?php $comments = $this->social_model->get_comments($val->P_ID); ?>
                                                                        <?php if (!empty($comments)) { ?>
                                                                            <a class="reply" data-toggle="collapse" data-target="#collapse_comments_<?php echo $val->P_ID; ?>" style="padding-right: 25px;"><i class="fa fa-eye"></i> Display comments</a>
                                                                        <?php } ?>
                                                                    </div>

                                                                    <div id="collapse_comments_<?php echo $val->P_ID; ?>" class="collapse">
                                                                        <div class="col-lg-12 col-xs-12">
                                                                            <ul class="comments">
                                                                                <?php $comments = $this->social_model->get_comments($val->P_ID); ?>
                                                                                <?php if ($comments != "") { ?>
                                                                                    <?php
                                                                                    foreach ($comments as $com) {
                                                                                        ?>
                                                                                        <?php $user = $this->users_model->get_user_by_id($com['User_commented_id']); ?>
                                                                                        <!-- Modal -->
                                                                                        <div id="reply<?php echo "_" . $com['C_Id']; ?>" class="modal fade" role="dialog">
                                                                                            <div class="modal-dialog">
                                                                                                <form method="post" enctype="multipart/form-data" action="<?php echo base_url() ?>social/replyToComment/<?php echo $com['C_Id']; ?>">  
                                                                                                    <!-- Modal content-->
                                                                                                    <div class="modal-content">
                                                                                                        <div class="modal-header">
                                                                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                                                            <h4 class="modal-title">Reply to <?php echo $user->Username . "'s"; ?> Comment</h4>
                                                                                                        </div> 
                                                                                                        <div class="modal-body">
                                                                                                            <div class="row">
                                                                                                                <div class="col-md-12 col-sm-12 col-xs-12 form-group form-group-back p-10">
                                                                                                                    <input required="" type="text" id="reply" name="reply" placeholder="Comment Reply" class="form-control">
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="modal-footer">
                                                                                                            <button type="submit" class="btn btn-dark">Reply</button>
                                                                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </form>
                                                                                            </div>
                                                                                        </div>

                                                                                        <li>
                                                                                            <div class="row">
                                                                                                <br>
                                                                                                <div class="col-md-1 col-xs-2">
                                                                                                    <?php
                                                                                                    if (!empty($user->Photo)) {
                                                                                                        ?>
                                                                                                        <!-- Current avatar -->
                                                                                                        <img src="<?php echo base_url(); ?>assets/photo/<?php echo $user->Photo; ?>" class="avatar" alt="Avatar">
                                                                                                    <?php } else { ?>
                                                                                                        <img src="<?php echo base_url(); ?>assets/images/user.png" alt="..." class="avatar">
                                                                                                    <?php } ?>
                                                                                                </div>
                                                                                                <div class="col-md-11 col-xs-10 comment-back">
                                                                                                    <h5><?php echo $user->Username; ?></h5>
                                                                                                    <p class="message"><?php echo $com['Content']; ?></p>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="message_wrapper col-md-11" style="margin-bottom: 5px">
                                                                                                <?php
                                                                                                $mSessionUserId = $this->session->userdata('User_Id');
                                                                                                $status = $this->social_model->check_like_for_comments($com['C_Id'], $mSessionUserId);
                                                                                                if ($status[0]['Status'] == ""):
                                                                                                    ?>
                                                                                                    <a href="<?php echo base_url() ?>social/likeComment/<?php echo $com['C_Id']; ?>" style="padding-right: 25px;"><i class="fa fa-thumbs-up"></i> (<?php echo $com['comment_likes_count']; ?>) Like</a>
                                                                                                <?php elseif ($status[0]['Status'] == "0"): ?>
                                                                                                    <a href="<?php echo base_url() ?>social/likeComment/<?php echo $com['C_Id']; ?>" style="padding-right: 25px;"><i class="fa fa-thumbs-up"></i> (<?php echo $com['comment_likes_count']; ?>) Like</a>
                                                                                                <?php else: ?>
                                                                                                    <a href="<?php echo base_url() ?>social/likeComment/<?php echo $com['C_Id']; ?>" style="padding-right: 25px;"><i class="fa fa-thumbs-down"></i> (<?php
                                                                                                        echo $com['comment_likes_count'];
                                                                                                        ?>) Unlike</a>
                                                                                                <?php endif; ?>
                                                                                                <a href="#" data-toggle="modal" data-target="#reply<?php echo "_" . $com['C_Id']; ?>" style="padding-right: 25px;"><i class="fa fa-reply"></i> Reply</a>
                                                                                                <?php
                                                                                                $mUserId = $this->session->userdata('User_Id');
                                                                                                $mPostUserId = $this->social_model->getPost($com['P_ID']);
                                                                                                if ($mUserId == $com['User_commented_id']) {
                                                                                                    ?>
                                                                                                    <a href="<?php echo base_url() ?>social/deleteComment/<?php echo $com['C_Id']; ?>"> <i class="fa fa-trash-o"></i> Delete</a>
                                                                                                <?php } elseif ($mPostUserId['Posted_User_Id'] == $mUserId) { ?>
                                                                                                    <a href="<?php echo base_url() ?>social/deleteComment/<?php echo $com['C_Id']; ?>"> <i class="fa fa-trash-o"></i> Delete</a>
                                                                                                <?php } else { ?>
                                                                                                <?php } ?>


                                                                                                <?php $replies = $this->social_model->get_replies($com['C_Id']); ?>

                                                                                                <?php if (!empty($replies)) { ?>

                                                                                                    <?php foreach ($replies as $reply) { ?>
                                                                                                        <?php $userReply = $this->users_model->get_user_by_id($reply['reply_by']); ?>
                                                                                                        <ul class="comments">
                                                                                                            <li>
                                                                                                                <div class="row">
                                                                                                                    <br>
                                                                                                                    <div class="col-md-1">
                                                                                                                        <?php
                                                                                                                        if (!empty($userReply->Photo)) {
                                                                                                                            ?>
                                                                                                                            <!-- Current avatar -->
                                                                                                                            <img src="<?php echo base_url(); ?>assets/photo/<?php echo $userReply->Photo; ?>" class="avatar" alt="Avatar">
                                                                                                                        <?php } else { ?>
                                                                                                                            <img src="<?php echo base_url(); ?>assets/images/user.png" alt="..." class="avatar">
                                                                                                                        <?php } ?>
                                                                                                                    </div>
                                                                                                                    <div class="col-md-11 comment-back">
                                                                                                                        <h5><?php echo $userReply->Username; ?></h5>
                                                                                                                        <p class="message"><?php echo $reply['reply_comment']; ?></p>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                                <div class="message_wrapper col-xs-12" style="margin-bottom: 5px">
                                                                                                                    <?php
                                                                                                                    $mUserId = $this->session->userdata('User_Id');
                                                                                                                    $mRepliedUserId = $this->social_model->getReply($reply['reply_id']);
                                                                                                                    if ($mUserId == $com['User_commented_id']) {
                                                                                                                        ?>
                                                                                                                        <a href="<?php echo base_url() ?>social/deleteReply/<?php echo $reply['reply_id']; ?>"> <i class="fa fa-trash-o"></i> Delete</a>
                                                                                                                    <?php } elseif ($mRepliedUserId['reply_by'] == $mUserId) { ?>
                                                                                                                        <a href="<?php echo base_url() ?>social/deleteReply/<?php echo $reply['reply_id']; ?>"> <i class="fa fa-trash-o"></i> Delete</a>
                                                                                                                    <?php } else { ?>
                                                                                                                    <?php } ?>
                                                                                                                </div>
                                                                                                            </li>
                                                                                                        </ul>
                                                                                                    <?php } ?>
                                                                                                <?php } ?>
                                                                                            </div>  

                                                                                        </li>
                                                                                    <?php }
                                                                                    ?>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        </div>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </ul>
                                        <!-- end of user messages -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="x_panel">
                                        <div class="x_title">
                                            <h2>Connections</h2>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="x_content">
                                            <article class="media event">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <a class="pull-left date" style="width: 100%">
                                                            <p class="month">Followers</p>
                                                            <p class="day">
                                                                <?php
                                                                if (!empty($connections)) {
                                                                    echo count($connections);
                                                                } else {
                                                                    echo "0";
                                                                }
                                                                ?>
                                                            </p>
                                                        </a>  
                                                    </div>
                                                    <div class="col-md-12">
                                                        <br>
                                                        <?php
                                                        $i = 1;
                                                        foreach (array_slice($connections, 0, 4) as $user) {
                                                            $userPicture = base_url('assets/photo/') . $user->Photo;
                                                            if (@getimagesize($userPicture)) {
                                                                $userPicture = $userPicture;
                                                            } else {
                                                                $userPicture = base_url('assets/images/user.png');
                                                            }
                                                            ?>
                                                            <a style="margin-right: 5px" target="_blank" href="<?php echo base_url('profile/index/') . $user->User_Id; ?>">
                                                                <img src="<?php echo $userPicture; ?>" class="avatar-circle"/>
                                                            </a>
                                                        <?php }
                                                        ?>
                                                    </div>
                                                </div>
                                            </article>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="x_panel">
                                        <div class="x_title">
                                            <h2>Posts</h2>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="x_content">
                                            <article class="media event">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <a class="pull-left date" style="width: 100%">
                                                            <p class="month">Wall Posts Count</p>
                                                            <p class="day">
                                                                <?php
                                                                if (!empty($posts)) {
                                                                    echo count($posts);
                                                                } else {
                                                                    echo "0";
                                                                }
                                                                ?>
                                                            </p>
                                                        </a>
                                                    </div>
                                                </div>
                                            </article>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <!-- /page content --> 


                <?php
                $i = 1;
                foreach ($posts as $val) {
                    ?>
                    <!-- Modal -->
                    <div id="comment<?php echo "_" . $val->P_ID; ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <form method="post" enctype="multipart/form-data" action="<?php echo base_url() ?>social/add_comment/<?php echo $val->P_ID; ?>">  
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Add Comment</h4>
                                    </div> 
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12 form-group form-group-back p-10">
                                                <input required="" type="text" id="comment" name="comment" placeholder="Post Comment" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-dark">Post</button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }
                ?>

                <?php
                $i = 1;
                foreach ($posts as $val) {
                    ?>
                    <!-- Modal -->
                    <div id="share<?php echo "_" . $val->P_ID; ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Share Post</h4>
                                </div> 
                                <div class="modal-body">
                                    <div class="row text-center">
                                        <a target="_blank" href="http://www.facebook.com/sharer.php?u=<?php echo base_url(); ?>social/singlePost/<?php echo $val->P_ID; ?>" class="fa fa-facebook-official fa-5x"></a>
                                        <a target="_blank" href="http://twitter.com/share?url=<?php echo base_url(); ?>social/singlePost/<?php echo $val->P_ID; ?>" class="fa fa-twitter-square fa-5x"></a>
                                        <a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo base_url(); ?>social/singlePost/<?php echo $val->P_ID; ?>" class="fa fa-linkedin-square fa-5x"></a>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }
                ?>
                <!-- footer content -->
                <?php $this->load->view('social/partials/footer') ?>
                <!-- /footer content --> 
            </div>
        </div>

        <?php $this->load->view('social/partials/assets-footer'); ?>
        <!-- Custom Theme Scripts --> 
        <script src="<?php echo base_url(); ?>assets/build/js/custom.min.js"></script> 
        <script>
                                                                document.addEventListener("touchstart", function () {}, true);
                                                                function empty_validate() {
                                                                    var a = document.getElementById('content').value;
                                                                    var b = document.getElementById('image').value;
                                                                    var c = document.getElementById('image').value;
                                                                    var d = document.getElementById('image').value;
                                                                    if ($('#content').val() || $('#image').val() || $('#video').val() || $('#link').val()) {
                                                                        return true;
                                                                    } else {
                                                                        alert("Empty Post cannot be posted.");
                                                                        return false;
                                                                    }
                                                                }

        </script>
        <script>
            function addId(id) {
                var id = id
                alert(id);
                $.ajax({
                    type: "post",
                    url: "<?php echo base_url('controller/function'); ?>",
                    data: {id: id},
                    cache: false,
                    async: false,
                    success: function (result) {
                        console.log(result);
                    }
                });
            }
        </script>
        <script>
            // Type change event
            $('#filterby').change(function () {
                $.post("<?php echo base_url('buyer/search/getFilterResults/'); ?>",
                        {
                            filter: this.value,
                        },
                        function (data, status) {
                            $('#products').html(data);
                        });
            });
        </script>
        <script>
            var loadFile = function (event) {
                var output = document.getElementById('output');
                output.src = URL.createObjectURL(event.target.files[0]);
            };
            $(document).on("change", ".file_multi_video", function (evt) {
                var $source = $('#video_here');
                $source[0].src = URL.createObjectURL(this.files[0]);
                $source.parent()[0].load();
            });
        </script>
        <script>
            $("#cancelImage").click(function () {
                $('#image').val('');
                $('#output').attr("src", "https://via.placeholder.com/150");
            });
            $("#cancelVideo").click(function () {
                $('#video').val('');
                $("#videoPreview").attr("src", "videos/Funny Cats.mp4");
            });
            $("#cancelLink").click(function () {
                $('#link').val('');
            });
            $("#linkClose").click(function () {
                $('#link').val('');
                $('#myModalLink').modal('hide');
            });
            $("#videoClose").click(function () {
                $('#video').val('');
                $('#myModalVideo').modal('hide');
                $("video").attr("src", "videos/Funny Cats.mp4");
            });
            $("#imageClose").click(function () {
                $('#image').val('');
                $('#myModalImage').modal('hide');
                $('#output').attr("src", "https://via.placeholder.com/150");
            });
        </script>
        <script type="text/javascript">
            $('#content').on('change', function () {
                // Change occurred so count chars...
                var comment = $.trim($("#content").val());
                $("#content_image").text(comment);
                $("#content_video").text(comment);
                $("#content_link").text(comment);
            });
        </script>
    </body>
</html>